# Google AI Studio Build Mode — Master Handoff Prompt

Copy everything below the divider heading ("Prompt to Paste into Google AI Studio") and paste it into the prompt box in [Google AI Studio Build Mode](https://aistudio.google.com/docs/aistudio-build-mode) while attaching `project_casework_docushield.html` (or after importing via [GitHub Two-Way Sync in AI Studio](https://aistudio.google.com/learn/sync-your-ai-studio-apps-with-github)) using the **Add files (`+`)** button.

## Prompt to Paste into Google AI Studio

You are an expert front-end design engineer working inside [Google AI Studio Build Mode](https://aistudio.google.com/docs/aistudio-build-mode) on the attached marketing website (`project_casework_docushield.html` / `index.html`) for **Project Casework** and **DocuShield**.

### 1. Strict Surgical-Edit & Preservation Rule

- **Do NOT regenerate from scratch or overwrite with a boilerplate template.** Treat the attached HTML file as the authoritative baseline codebase.
- Preserve all existing HTML sections, DOM element IDs, grounded copy, embedded editorial images, and interactive JavaScript controllers unless I explicitly ask to modify or replace a specific section.
- Keep the project running cleanly as a zero-build portable HTML experience (or if I explicitly ask to split files later, extract only the two inline base64 images into local image files while keeping every style rule and animation intact).

### 2. Core Product & Marketing Guardrails

- **Marketing & Consumer-Connection Front End Only:** This website is strictly the public-facing marketing and inquiry front end connecting prospective consumers, community nonprofits, housing authorities, legal clinics, healthcare organizations, government departments, and private teams with our team.
- **Never Embed the Software App Workspace:** Do **not** add document-upload dropzones, live file scanners, cloud API upload endpoints, or internal caseworker dashboards to this website. Our core brand promise is that sensitive constituent and consumer files never touch public web servers—both programs run 100% locally inside an air-gapped workstation perimeter.
- **Dual-Program Positioning ("Versatility That Assists All"):**
  - **Project Casework:** Streamlines multi-document intake packets, standardizes eligibility checklists, and produces clean, audit-ready review summaries.
  - **DocuShield:** Performs 100% local, network-isolated forensic verification on bank statements, paystubs, utility bills, tax filings, and residential leases to catch subtle alterations before funds are disbursed.
  - Emphasize universal versatility across all six audience tracks (Housing & Rental Support, Nonprofits & Shelters, Utility & Community Relief, Legal Aid & Consumer Defense, Health/Child Care/Disability, and Private Teams & Everyday Users), grounded in our mapped ecosystem of 302 distinct California organizations (162 Nonprofits and 140 Public/Government agencies across 8 correlated sectors from the [California Agency Outreach & Marketing Directory](https://docs.google.com/spreadsheets/d/1hQ3sFIbUceA_wbfdp-IXSD10OY3yuDxHsZn3TOKw-Ec/edit)).

### 3. Locked-In Visual Identity (Forensic Dark + Cabernet + Editorial Serif)

Maintain these exact CSS custom properties on `:root` and never revert to generic blue/purple SaaS palettes or sans-only headings:

| Design Token | Locked Value | Visual Role & Reference |
| :--- | :--- | :--- |
| `--bg-page` / `--bg-alt` / `--bg-card` | `#0D090C` / `#150E13` / `#1C131A` | Forensic Dark obsidian-plum surfaces styled with [Tailwind CSS](https://tailwindcss.com/docs/theme) utilities |
| `--burgundy-core` / `--burgundy-base` / `--burgundy-deep` | `#470E1D` / `#6B182E` / `#340814` | Primary Dark Cabernet brand gradients, CTAs, and active tab pills |
| `--burgundy-bright` | `#C43E62` | Luminous Cabernet rim highlights, focus rings, and hover spotlights |
| `--accent-gold` | `#D8AD72` | Brushed champagne-gold eyebrows, laser tips, and micro-spark accents |
| `--accent-verify` | `#2DD4BF` | Forensic verification badges and on-device perimeter indicators |
| `--font-display` | `Georgia, 'Iowan Old Style', 'Palatino Linotype', serif` | Editorial Serif display typography across all hero, section, and card titles |

### 4. Technical Stack & Interactive Motion Contract

Preserve and match these existing libraries and interaction patterns whenever adding new UI elements:

- **CDN Stack:** [Tailwind CSS](https://tailwindcss.com/docs/theme) (`3.4.17`), [GSAP v3](https://gsap.com/docs/v3/) (`3.12.5`), [GSAP ScrollTrigger](https://gsap.com/docs/v3/Plugins/ScrollTrigger/animation/) (`3.12.5`), and [Lucide Icons](https://www.jsdelivr.com/package/npm/lucide) (`0.460.0` UMD).
- **Scroll Animations:** Preserve the fixed top cabernet-to-gold optical progress beam (`#scroll-progress-bar`), scrubbed parallax ambient orbs, blur-to-crisp `.gs-heading` reveals, staggered `.gs-card-group` cascades, rolling `.counter-num` metrics, and active navigation scroll-spy (`data-spy-link`).
- **Hover Micro-Interactions:** Apply `.spotlight-card` (`--mx`, `--my` radial cursor spotlight) to new cards, `.magnetic-btn` spring pull + specular sheen to primary CTAs, center-outward `.nav-link-anim` underlines to links, and 3D perspective tilt + `.tilt-glare` to visual showcase frames.
- **Click Animations on Allowable Interactions:** Wire new interactive controls to `spawnClickBurst(e, targetEl)` (concentric cabernet-gold shockwave ring + 6 radial sparks + elastic spring bounce) and `flashCardBorder(el)` on state transitions.
- **Accessibility & Sandbox Safety:** Honor the `#top-motion-toggle` (`data-motion="reduced"`), [U.S. Section 508 Web Content Accessibility Standards](https://www.section508.gov/develop/web-content/), and [MDN CSS `prefers-reduced-motion`](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion). Never use `alert()`, `confirm()`, or `prompt()`; always use `#app-toast` or `#briefing-modal`.

### 5. First Task in This Session

1. Load and render the attached `project_casework_docushield.html` as `index.html` without altering its visual look, copy, or animations.
2. Confirm that all 7 sections (`#hero`, `#programs`, `#story-stage`, `#versatility`, `#zero-cloud`, `#pathways`, `#faq`, and `#connect`), both embedded editorial visuals, and all GSAP scroll/hover/click interactions are live in the preview.
3. Wait for my next experiment instruction—or apply the specific experiment below if filled in:

**My First Experiment Request:** `[Replace this line with what you want to try first — e.g., "Add an interactive Case Study spotlight carousel between Versatility and Zero-Cloud Privacy using the same Forensic Dark + Cabernet spotlight cards and click shockwaves."]`

## Ready-to-Swap Experiment Prompts for Follow-Up Turns

Once your page is loaded in [Google AI Studio Build Mode](https://aistudio.google.com/docs/aistudio-build-mode), you can paste any of these short follow-up prompts to run new visual experiments without breaking your foundation:

- **Experiment 1 — Interactive Before/After Casework Time-Savings Slider:** *"Add a sleek interactive slider section above `#pathways` where visitors can adjust monthly intake packet volume (from 25 to 5,000 packets) and see animated visual bars comparing manual paper review hours vs. organized local workflows with Project Casework and DocuShield, styled in our Forensic Dark + Cabernet `.spotlight-card` system."*
- **Experiment 2 — Split Inline Base64 Images for Faster Editing:** *"Extract the two inline `data:image/jpeg;base64,...` strings in `index.html` into standalone image files (`public/hero-prism.jpg` and `public/community-center.jpg`) and update their `src` attributes so `index.html` stays lightweight while looking 100% identical."*
- **Experiment 3 — Audience Testimonial & Use-Case Story Drawer:** *"Add a clickable 'Read Real-World Scenario' drawer on each of the 6 `#versatility` audience cards that slides open with a custom GSAP animation to show a day-in-the-life scenario for that sector without adding any file-upload UI."*
- **Experiment 4 — Multi-Language Civic Accessibility Switcher (EN / ES / HY):** *"Add an animated language switcher pill in the header (`EN` / `ES` / `ՀԱՅ`) with click shockwaves that translates the hero, program summaries, and connection form labels smoothly in place for Southern California communities."*
